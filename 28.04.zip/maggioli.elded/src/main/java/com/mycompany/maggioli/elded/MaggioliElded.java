/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.maggioli.elded;

/**
 *
 * @author PC11
 */
public class MaggioliElded {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
